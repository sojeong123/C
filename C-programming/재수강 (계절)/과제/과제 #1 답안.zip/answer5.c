#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
    int input;
    int h = 0, m = 0, s = 0;
    printf("��(Second)�� �Է��ϼ���: ");
    scanf("%d", &input);

    h = input / 3600;
    m = (input % 3600) / 60;
    s = (input % 3600) % 60;

    printf("%2d�� %2d�� %2d��\n", h, m, s);
    return 0;
}
