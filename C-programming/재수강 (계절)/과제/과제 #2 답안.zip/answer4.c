#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	int cnt = 0, num = 2;

	printf("10���� �Ҽ� ���: ");
	while (cnt < 10)
	{
		for (int j = 2; j <= num; j++)
		{
			if (j == num)
			{
				printf("%d ", num);
				cnt++;
			}
			else if (num % j == 0)
				break;
		}
		num++;
	}
	return 0;
}
