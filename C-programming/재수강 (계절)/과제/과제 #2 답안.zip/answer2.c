#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
	int num1, num2;
	int tmp;

	printf("�� ���� ������ �Է��ϼ���: ");
	scanf("%d %d", &num1, &num2);

	if (num2 < num1)
	{
		tmp = num1;
		num1 = num2;
		num2 = tmp;
	}
	for (int j = num1; j <= num2; j++)
	{
		for (int k = 1; k < 10; k++)
			printf("%d * %d = %2d\n", j, k, j * k);
		printf("\n");
	}
	return 0;
}
