#include <stdio.h>
int main(void)
{
	int num;
	int interger;
	int count = 0;
	int i;

	printf("Enter the # of intergers : ");
	scanf("%d", &num);

	for (i = 1; i <= num; i++)
	{
		printf("Enter an interger : ");
		scanf("%d", &interger);
	
		if (interger % 2 == 0)
			count++;
	}

	printf("The number of even number is %d. \n", count);

	return 0;
}