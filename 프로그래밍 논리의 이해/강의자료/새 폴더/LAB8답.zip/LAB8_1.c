#include <stdio.h>

int main(void)
{
	int num;
	int i;

	printf("Enter a number : ");
	scanf("%d", &num);

	for (i = 1; i <= num; i++)
		printf("%d \n", i * i * i);

	return 0;
}