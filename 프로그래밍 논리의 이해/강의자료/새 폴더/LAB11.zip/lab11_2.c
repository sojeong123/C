#include <stdio.h>
int pow(int x, int y);
int main(void)
{
	int x, y;

	printf("Enter the number X: ");
	scanf("%d", &x);
	printf("Enter the number Y: ");
	scanf("%d", &y);

	printf("%d ^ %d == %d\n", x, y, pow(x, y));	/* �̺κ��� �Լ� ȣ��� ä�켼�� */
}

int pow(int x, int y)
{
	int i, result = 1;
	for (i = 0; i < y; i++)
		result *= x;
	return result;
}
