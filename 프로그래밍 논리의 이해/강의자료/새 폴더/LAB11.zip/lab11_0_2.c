
int square2(int n);
#include <stdio.h>
int main(void)
{
	int result;
	result = square2(5); 
	printf("������ %d\n", result);
}

int square2(int n)
{
	return n * n;
}
