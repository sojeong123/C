
int square1(void);

#include <stdio.h>
int main(void)
{
	int result;
	result = square1();
	printf("������ %d\n", result);
}

int square1(void)
{
	int x = 5;

	return x * x;
}
